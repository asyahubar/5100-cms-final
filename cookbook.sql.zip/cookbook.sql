-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 01, 2018 at 09:09 PM
-- Server version: 5.7.19
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cookbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `title`) VALUES
(5, 'active dry yeast'),
(7, 'baking powder'),
(1, 'butter'),
(22, 'chives'),
(16, 'chocolate hazelnut spread'),
(15, 'cocoa powder'),
(3, 'cream cheese'),
(6, 'flour'),
(21, 'garlic'),
(4, 'granulated sugar'),
(18, 'ground black pepper'),
(10, 'ground cinnamon'),
(20, 'heavy cream'),
(9, 'light brown sugar'),
(2, 'milk'),
(19, 'potato'),
(12, 'powdered sugar'),
(8, 'salt'),
(11, 'vanilla extract'),
(17, 'vegetable oil');

-- --------------------------------------------------------

--
-- Table structure for table `measurments`
--

CREATE TABLE `measurments` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `measurments`
--

INSERT INTO `measurments` (`id`, `title`) VALUES
(6, 'clove'),
(1, 'g'),
(2, 'mL'),
(5, 'pack'),
(4, 'tbsp'),
(7, 'to taste'),
(3, 'tsp');

-- --------------------------------------------------------

--
-- Table structure for table `pivot`
--

CREATE TABLE `pivot` (
  `id` int(10) UNSIGNED NOT NULL,
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `ingredient_id` int(10) UNSIGNED NOT NULL,
  `measurment_id` int(10) UNSIGNED NOT NULL,
  `ingredient_count` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pivot`
--

INSERT INTO `pivot` (`id`, `recipe_id`, `ingredient_id`, `measurment_id`, `ingredient_count`) VALUES
(1, 1, 1, 1, 335),
(2, 1, 2, 2, 530),
(3, 1, 4, 1, 100),
(4, 1, 5, 5, 1),
(5, 1, 6, 1, 625),
(6, 1, 7, 3, 1),
(7, 1, 8, 3, 1),
(8, 1, 9, 1, 165),
(9, 1, 10, 4, 2),
(10, 1, 11, 3, 1),
(11, 1, 12, 1, 120),
(12, 2, 6, 4, 4),
(13, 2, 9, 4, 3),
(14, 2, 15, 4, 2),
(15, 2, 17, 4, 1),
(16, 2, 11, 3, 1),
(17, 2, 16, 4, 1),
(18, 2, 12, 1, 0),
(19, 2, 7, 4, 0.5),
(28, 3, 19, 1, 900),
(29, 3, 2, 2, 120),
(30, 3, 20, 2, 120),
(31, 3, 21, 6, 8),
(32, 3, 1, 1, 115),
(33, 3, 8, 3, 2),
(34, 3, 22, 7, 0),
(35, 3, 18, 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `time_preparing` int(6) UNSIGNED DEFAULT NULL,
  `instructions` mediumtext NOT NULL,
  `image` varchar(2100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`id`, `title`, `time_preparing`, `instructions`, `image`) VALUES
(1, 'Homemade Cinnamon Rolls', 150, 'Generously butter two disposable foil pie or cake pans.\r\nIn a large bowl, whisk together warm milk, melted butter, and granulated sugar. The mixture should be just warm, registering between 37-43˚C. If it is hotter, allow to cool slightly.\r\nSprinkle the yeast evenly over the warm mixture and let set for 1 minute.\r\nAdd 4 cups (500g) of all-purpose flour to the milk mixture and mix with a wooden spoon until just combined.\r\nCover the bowl with a towel or plastic wrap and set in a warm place to rise for 1 hour.\r\nAfter 1 hour, the dough should have nearly doubled in size.\r\nRemove the towel and add an additional 3/4 cup (95g) of flour, the baking powder, and salt. Stir well, then turn out onto a well-floured surface.\r\nKnead the dough lightly, adding additional flour as necessary, until the dough just loses its stickiness and does not stick to the surface.\r\nRoll the dough out into a large rectangle, about ½-inch (1 cm) thick. Fix corners to make sure they are sharp and even.\r\nSpread the softened butter evenly over the dough.\r\nSprinkle evenly with brown sugar and a generous sprinkling of cinnamon.\r\nPress the mixture into the butter.\r\nRoll up the dough, forming a log, and pinch the seam closed. Place seam-side down. Trim off any unevenness on either end.\r\nCut the log in half, then divide each half into 7 evenly sized pieces. About 1 1/2 inches (8cm) thick each.\r\nPlace 7 cinnamon rolls in each cake pan, one in the center, six around the sides. Cover with plastic wrap and place in a warm place to rise for 30 minutes.\r\nPreheat oven to 350˚F (180˚C).\r\nTo prepare the frosting. In a medium-size mixing bowl, whisk together cream cheese, butter, whole milk, vanilla, and powdered sugar, until smooth.\r\nRemove plastic wrap. Bake the cinnamon rolls in a preheated oven for 25-30 minutes, until golden brown.\r\nWhile still warm, drizzle evenly with frosting.\r\nEnjoy!', ''),
(2, 'Chocolate Hazelnut Mug Cake', 30, 'In a 375 m) mug or larger, mix all ingredients (except the chocolate hazelnut spread) until just combined.\r\nOnce combined, spoon the chocolate hazelnut spread on top of the batter.\r\nMicrowave on high for 90 seconds to 2 minutes, watching to make sure it doesn’t spill over (depending on the size of the mug).\r\nLet cool one minute before eating. Top with additional chocolate hazelnut spread and powdered sugar (optional).\r\nEnjoy!', ''),
(3, 'Mashed Potatoes', 60, 'On a cutting board, peel the potatoes. Place the potatoes in a large bowl of cold water after peeling to avoid discoloration.\r\nCut the potatoes into 2 cm cubes.\r\nAdd the potatoes to a large pot and cover with cold water. Bring to a boil over high heat, then reduce the heat to low and simmer for 12 minutes.\r\nIn a small saucepan, bring the milk, heavy cream, and garlic to a simmer over low heat.\r\nRemove the pot from the heat and strain the cream through a fine mesh sieve.\r\nDrain the potatoes in a colander and transfer back to the pot.\r\nMash the potatoes with a potato masher, potato ricer, or by pushing through a fine mesh sieve with a spatula.\r\nAdd the cubed cold butter and salt. Stir to combine.\r\nGradually add the cream mixture to the potatoes, little by little, until fully incorporated.\r\nTop with freshly ground black pepper and sprinkle with chives and serve.\r\nEnjoy!', '');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `nickname` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `title_UNIQUE` (`title`);

--
-- Indexes for table `measurments`
--
ALTER TABLE `measurments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `title_UNIQUE` (`title`);

--
-- Indexes for table `pivot`
--
ALTER TABLE `pivot`
  ADD PRIMARY KEY (`id`,`recipe_id`,`ingredient_id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_recepies_has_ingredients_ingredients1_idx` (`ingredient_id`),
  ADD KEY `fk_recepies_has_ingredients_recepies_idx` (`recipe_id`),
  ADD KEY `fk_recepies_has_ingredients_measurments1_idx` (`measurment_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`,`role_id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `nickname_UNIQUE` (`nickname`),
  ADD KEY `fk_users_roles1_idx` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `measurments`
--
ALTER TABLE `measurments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pivot`
--
ALTER TABLE `pivot`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pivot`
--
ALTER TABLE `pivot`
  ADD CONSTRAINT `fk_recepies_has_ingredients_ingredients1` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_recepies_has_ingredients_measurments1` FOREIGN KEY (`measurment_id`) REFERENCES `measurments` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_recepies_has_ingredients_recepies` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_roles1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
